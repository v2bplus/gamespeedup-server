/* This is a generated file, edit the .stub.php file instead.
 * Stub hash: 68d96eda78f44c62790e782902e75f0254491527 */

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Router___construct, 0, 0, 0)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Router_addRoute, 0, 0, 2)
	ZEND_ARG_INFO(0, name)
	ZEND_ARG_INFO(0, route)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Router_addConfig, 0, 0, 1)
	ZEND_ARG_INFO(0, config)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Router_route, 0, 0, 1)
	ZEND_ARG_INFO(0, request)
ZEND_END_ARG_INFO()

ZEND_BEGIN_ARG_INFO_EX(arginfo_class_Yaf_Router_getRoute, 0, 0, 1)
	ZEND_ARG_INFO(0, name)
ZEND_END_ARG_INFO()

#define arginfo_class_Yaf_Router_getRoutes arginfo_class_Yaf_Router___construct

#define arginfo_class_Yaf_Router_getCurrentRoute arginfo_class_Yaf_Router___construct
